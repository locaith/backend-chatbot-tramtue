"""
API package initialization
"""