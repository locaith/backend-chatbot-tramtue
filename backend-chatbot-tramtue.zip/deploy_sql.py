#!/usr/bin/env python3
"""
Deploy SQL migration to Supabase database
"""
import os
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def deploy_sql_migration():
    """Deploy SQL migration to Supabase"""
    
    try:
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        
        if not supabase_url or not supabase_key:
            print("❌ Missing Supabase credentials in .env file")
            return False
        
        # Read SQL migration file
        with open("migrations/001_initial_schema.sql", "r", encoding="utf-8") as f:
            sql_content = f.read()
        
        print("📄 SQL migration file loaded")
        print(f"📊 SQL content length: {len(sql_content)} characters")
        
        # Split SQL into individual statements
        statements = [stmt.strip() for stmt in sql_content.split(';') if stmt.strip()]
        
        print(f"🔧 Found {len(statements)} SQL statements to execute")
        
        headers = {
            "apikey": supabase_key,
            "Authorization": f"Bearer {supabase_key}",
            "Content-Type": "application/json"
        }
        
        success_count = 0
        error_count = 0
        
        for i, statement in enumerate(statements, 1):
            if not statement.strip():
                continue
                
            print(f"\n🔄 Executing statement {i}/{len(statements)}...")
            
            # Execute SQL statement via RPC
            payload = {
                "query": statement
            }
            
            try:
                response = requests.post(
                    f"{supabase_url}/rest/v1/rpc/exec_sql",
                    headers=headers,
                    json=payload
                )
                
                if response.status_code in [200, 201, 204]:
                    print(f"✅ Statement {i} executed successfully")
                    success_count += 1
                else:
                    print(f"⚠️ Statement {i} warning: {response.status_code} - {response.text[:200]}")
                    # Some statements might return warnings but still succeed
                    success_count += 1
                    
            except Exception as e:
                print(f"❌ Statement {i} failed: {str(e)}")
                error_count += 1
        
        print(f"\n📊 Migration Summary:")
        print(f"✅ Successful: {success_count}")
        print(f"❌ Failed: {error_count}")
        
        if error_count == 0:
            print("\n🎉 SQL migration deployed successfully!")
            return True
        else:
            print(f"\n⚠️ Migration completed with {error_count} errors")
            return False
        
    except Exception as e:
        print(f"❌ Migration deployment failed: {str(e)}")
        return False

if __name__ == "__main__":
    print("🚀 Deploying SQL migration to Supabase...\n")
    success = deploy_sql_migration()
    
    if success:
        print("\n✅ Migration deployment completed!")
    else:
        print("\n❌ Migration deployment failed. Please check manually in Supabase dashboard.")