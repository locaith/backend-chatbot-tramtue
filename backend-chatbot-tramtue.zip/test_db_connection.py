#!/usr/bin/env python3
"""
Test script to verify Supabase database connection and schema
"""
import asyncio
import os
from dotenv import load_dotenv
from supabase import create_client, Client

# Load environment variables
load_dotenv()

async def test_database_connection():
    """Test Supabase connection and verify tables"""
    
    try:
        # Initialize Supabase client
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        
        if not supabase_url or not supabase_key:
            print("❌ Missing Supabase credentials in .env file")
            return False
        
        supabase: Client = create_client(supabase_url, supabase_key)
        print("✅ Supabase client initialized")
        
        # Test basic connection
        response = supabase.table("users").select("count", count="exact").execute()
        print(f"✅ Database connection successful")
        print(f"📊 Users table exists (count: {response.count})")
        
        # Test all tables exist
        tables_to_check = [
            "users", "conversations", "messages", "memories",
            "documents", "doc_chunks", "doc_embeddings",
            "timers", "handoffs", "metrics"
        ]
        
        for table in tables_to_check:
            try:
                response = supabase.table(table).select("count", count="exact").execute()
                print(f"✅ Table '{table}' exists (count: {response.count})")
            except Exception as e:
                print(f"❌ Table '{table}' error: {str(e)}")
        
        # Test vector extension
        try:
            response = supabase.rpc("vector_search", {
                "query_embedding": [0.1] * 384,
                "match_threshold": 0.5,
                "match_count": 1
            }).execute()
            print("✅ Vector search function working")
        except Exception as e:
            print(f"⚠️ Vector search function error: {str(e)}")
        
        print("\n🎉 Database setup verification completed!")
        return True
        
    except Exception as e:
        print(f"❌ Database connection failed: {str(e)}")
        return False

if __name__ == "__main__":
    print("🔍 Testing Supabase database connection...\n")
    success = asyncio.run(test_database_connection())
    
    if success:
        print("\n✅ All tests passed! Database is ready.")
    else:
        print("\n❌ Some tests failed. Please check your configuration.")