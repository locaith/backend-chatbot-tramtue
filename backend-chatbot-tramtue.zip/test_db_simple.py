#!/usr/bin/env python3
"""
Simple test script to verify Supabase database connection using HTTP requests
"""
import os
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def test_supabase_connection():
    """Test Supabase connection using REST API"""
    
    try:
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        
        if not supabase_url or not supabase_key:
            print("❌ Missing Supabase credentials in .env file")
            return False
        
        # Test connection by checking users table
        headers = {
            "apikey": supabase_key,
            "Authorization": f"Bearer {supabase_key}",
            "Content-Type": "application/json"
        }
        
        # Test basic connection
        response = requests.get(
            f"{supabase_url}/rest/v1/users?select=count",
            headers=headers
        )
        
        if response.status_code == 200:
            print("✅ Supabase connection successful")
            print(f"📊 Users table accessible")
        else:
            print(f"❌ Connection failed: {response.status_code} - {response.text}")
            return False
        
        # Test all tables exist
        tables_to_check = [
            "users", "conversations", "messages", "memories",
            "documents", "doc_chunks", "doc_embeddings",
            "timers", "handoffs", "metrics"
        ]
        
        for table in tables_to_check:
            try:
                response = requests.get(
                    f"{supabase_url}/rest/v1/{table}?select=count",
                    headers=headers
                )
                if response.status_code == 200:
                    print(f"✅ Table '{table}' exists and accessible")
                else:
                    print(f"❌ Table '{table}' error: {response.status_code}")
            except Exception as e:
                print(f"❌ Table '{table}' error: {str(e)}")
        
        print("\n🎉 Database schema verification completed!")
        return True
        
    except Exception as e:
        print(f"❌ Database connection failed: {str(e)}")
        return False

if __name__ == "__main__":
    print("🔍 Testing Supabase database connection...\n")
    success = test_supabase_connection()
    
    if success:
        print("\n✅ All tests passed! Database is ready.")
    else:
        print("\n❌ Some tests failed. Please check your configuration.")